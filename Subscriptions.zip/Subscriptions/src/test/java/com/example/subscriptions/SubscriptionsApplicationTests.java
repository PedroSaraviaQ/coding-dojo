package com.example.subscriptions;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SubscriptionsApplicationTests {
    
    @Test
    void contextLoads() {
    }
    
}
