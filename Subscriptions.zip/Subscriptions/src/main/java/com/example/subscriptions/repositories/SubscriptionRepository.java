package com.example.subscriptions.repositories;

import com.example.subscriptions.models.Subscription;

public interface SubscriptionRepository extends BaseRepository<Subscription> {
}
