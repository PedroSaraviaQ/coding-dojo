package com.example.subscriptions.services;

import com.example.subscriptions.models.Subscription;
import org.springframework.stereotype.Service;

@Service
public class SubscriptionService extends BaseService<Subscription> {
}
