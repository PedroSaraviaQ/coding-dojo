package com.example.controllersandviews;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControllersAndViewsApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(ControllersAndViewsApplication.class, args);
    }
    
}
